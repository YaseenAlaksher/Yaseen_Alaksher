function login() {
    let username = document.getElementById('username').value;
    let password = document.getElementById('password').value;
    if (username && password) {
        document.getElementById('login-container').classList.add('hidden');
        document.getElementById('calculator-container').classList.remove('hidden');
    } else {
        alert('Please enter username and password');
    }
}
function appendValue(value) {
    document.getElementById('display').value += value;
}
function clearDisplay() {
    document.getElementById('display').value = '';
}
function calculate() {
    try {
        document.getElementById('display').value = eval(document.getElementById('display').value);
    } catch (e) {
        alert('Invalid Operation');
    }
}
function changeTheme(theme) {
    document.body.className = theme;
}
